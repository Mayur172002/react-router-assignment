import React, { useEffect, useState } from 'react'
import Header from '../Componest/Header'
import Footar from '../Componest/Footar'
import axios from 'axios'
import { Link, useNavigate, useParams } from 'react-router-dom';
import './Web.style.css';

function View_shop() {
    useEffect(() => {
        fetch();
        fetch1();
    }, [])
    const { prod_id } = useParams();
    const [data, setdata] = useState([])
    const fetch = async () => {
        const result = await axios.get(`http://localhost:3000/Products?prod_id=${prod_id}`)
        console.log(result.data);
        setdata(result.data)
    }

    const [data1, setdata1] = useState([])
    const fetch1 = async () => {
        const result = await axios.get(`http://localhost:3000/Categories?id=${prod_id}`)
        console.log(result.data);
        setdata1(result.data)
    }

    return (
        <div>
            <Header />
            <div className="page-hero bg-image overlay-dark" style={{ backgroundImage: 'url(https://cdn.pixabay.com/photo/2018/01/17/07/14/pharmacy-3087599_1280.jpg)' }}>
                <div className="hero-section">
                    <div className="container text-center wow zoomIn">
                        <h1 className="display-6">Buy Medicines</h1>
                        <a href="#" className="btn btn-primary">Shop Now</a>
                    </div>
                </div>
            </div>
            <div className="page-section py-3 mt-md-n5 custom-index">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-md-4 py-3 py-md-0" >
                            <div className="card-service wow fadeInUp" style={{ background: "#ffede3" }}>
                                <img src="https://doccure.dreamstechnologies.com/html/template/assets/img/products/product-16.png" width="100%" height="100px" style={{ objectFit: "contain" }} alt="" />
                                <p style={{ fontSize: "15px" }}> 10% Cashback on Dietary Suppliments</p>
                            </div>
                        </div>
                        <div className="col-md-4 py-3 py-md-0">
                            <div className="card-service wow fadeInUp" style={{ background: "#d6f8ff" }}>
                                <img src="https://doccure.dreamstechnologies.com/html/template/assets/img/products/product-17.png" width="100%" height="100px" style={{ objectFit: "contain" }} alt="" />
                                <p style={{ fontSize: "15px" }}>New Throat Freshner</p>
                            </div>
                        </div>
                        <div className="col-md-4 py-3 py-md-0">
                            <div className="card-service wow fadeInUp" style={{ background: "#f6eeff" }}>
                                <img src="https://doccure.dreamstechnologies.com/html/template/assets/img/products/product-18.png" width="100%" height="100px" style={{ objectFit: "contain" }} alt="" />
                                <p style={{ fontSize: "15px" }}>Get a Product Worth 1000 in a Pack</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> {/* .page-section */}

            <div className="page-section">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-lg-8 wow fadeInUp">
                            <h1 className="text-center mb-3">Welcome to Your Products</h1>
                            <div className="text-lg">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt neque sit, explicabo vero nulla animi nemo quae cumque, eaque pariatur eum ut maxime! Tenetur aperiam maxime iure explicabo aut consequuntur. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt neque sit, explicabo vero nulla animi nemo quae cumque, eaque pariatur eum ut maxime! Tenetur aperiam maxime iure explicabo aut consequuntur.</p>
                            </div>
                        </div>
                        

                        {
                            data1 && data1.map((value) => {
                                return (
                                    <div className="row mt-5  wow fadeInUp">
                                        <h1 className='mb-4 mt-4 ' style={{ fontSize: "25px", fontWeight: "550" }}>{value.name} Products</h1>
                                    </div>
                                )
                            })
                        }

                        {
                            data && data.map((value) => {
                                return (
                                    <div className="col-md-4 product_card mt-4 " >
                                        <div className="card hover">
                                            <Link to={'/single_product/' + value.id} className='text-dark' style={{textDecoration : "none"}}>
                                            <img className="card-img-top" src={value.image} width='100%' height='200px' style={{ objectFit: "contain" }} alt="Card image cap" />
                                            <div className="card-block ms-3">
                                                <h1 className="card-title mt-3 mb-3 product_name  " style={{ fontSize: "18px", fontWeight: "550", }}>{value.name}</h1>
                                                {/* <span className='' style={{ color: "orangered" }}>₹18 cashback</span> */}
                                                <div className='d-flex mt-3 gap-5 justify-content-between '>
                                                    <div className='d-flex'>
                                                        <h1 style={{ fontSize: "20px", fontWeight: "600" }}>₹{value.price}</h1>
                                                        <p className='ms-1 25px text-primary' style={{ fontWeight: "550", fontSize: "12px" }}>{value.disc} off</p>
                                                    </div>
                                                    <Link to={'/single_product/' + value.id}  className="btn btn-outline-primary btn-rounded mb-2 me-2 w-40">Add</Link>
                                                </div>
                                            </div>
                                            </Link>
                                        </div>
                                    </div>
                                )
                            })
                        }

                    </div>
                </div>
            </div>
            <Footar />
        </div>
    )
}

export default View_shop